# 天气实景背景图（sky backgrounds）设计 Brief

- **任务**：为「天气聚合」应用深色主题生成 8 张天气实景背景，随当前天气状况切换（苹果天气风格）。
- **主题**：真实天空场景（写实摄影质感）。
- **商品**：无实体商品；核心对象为 8 种天气天空：晴 / 局部多云 / 多云阴 / 雨 / 雪 / 雾 / 雷暴 / 夜空。
- **尺寸**：2048×1152（16:9，应用窗口约 1260×860，PreserveAspectCrop 裁切安全）。
- **视觉语言**：深色电影感写实天空，上 2/3 天空 + 下 1/4 深色城市天际线剪影（暗调，保证液态玻璃卡片可读），无文字、无 UI、无人物、无标志。
- **映射**：clear→晴；partly/night_partly→局部多云；cloudy/overcast→多云阴；rain/heavy_rain/showers/heavy_showers/drizzle/freezing→雨；snow 系→雪；fog→雾；thunder/thunder_hail→雷暴；night_clear/night_partly→夜空。
- **用途**：F:\weather\assets\ui\sky\sky_<key>.png，深色主题 bgImage 动态引用；浅色主题保持浅色渐变不覆盖。
- **验收**：每张与对应天气匹配、整体暗调不抢 UI、无文字瑕疵、16:9 构图。
